#!/system/bin/sh

MODULE_ID="pura80ultra_semantics"
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/$MODULE_ID"

TARGET_NAME="HUAWEI Pura 80 Ultra"
OFFICIAL_SHA256_URL="https://raw.githubusercontent.com/cjzyypok/Pura80Ultra-Semantics/main/official.sha256"
FAIL_DESC="Unofficial version, disabled"
STATE_FILE="$MODDIR/.integrity_state"
ENABLE_FILE="$MODDIR/.enabled"
PROP_FILE="$MODDIR/module.prop"
ZYGISK_SO="$MODDIR/zygisk/arm64-v8a.so"

print_line() {
    echo "- $1"
}

sha256_file() {
    local file="$1"
    [ -f "$file" ] || return 1
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    if command -v toybox >/dev/null 2>&1; then
        toybox sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    return 1
}

set_prop() {
    local key="$1"
    local val="$2"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop "$key" "$val" >/dev/null 2>&1
    else
        setprop "$key" "$val" >/dev/null 2>&1
    fi
}

set_description() {
    local desc="$1"
    local tmp="$PROP_FILE.tmp.$$"
    local seen=0
    [ -f "$PROP_FILE" ] || return 0

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            description=*)
                echo "description=$desc"
                seen=1
                ;;
            *)
                echo "$line"
                ;;
        esac
    done < "$PROP_FILE" > "$tmp"

    [ "$seen" = "1" ] || echo "description=$desc" >> "$tmp"
    mv "$tmp" "$PROP_FILE"
}

download_remote_hashes() {
    local out="$1"
    rm -f "$out"

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL "$OFFICIAL_SHA256_URL" -o "$out" >/dev/null 2>&1 && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$out" "$OFFICIAL_SHA256_URL" >/dev/null 2>&1 && return 0
    fi
    if command -v toybox >/dev/null 2>&1; then
        toybox wget -q -O "$out" "$OFFICIAL_SHA256_URL" >/dev/null 2>&1 && return 0
    fi
    return 1
}

remote_expected_hash() {
    local manifest="$1"
    local name="$2"
    awk -v n="$name" '{
        for (i = 1; i < NF; i += 2) {
            if ($i == n) {
                print $(i + 1)
                exit
            }
        }
    }' "$manifest" 2>/dev/null | tr -d '\r'
}

check_remote_hashes() {
    local manifest="$MODDIR/.official_sha256"
    local prop_expected
    local so_expected
    local prop_hash
    local so_hash

    download_remote_hashes "$manifest" || return 2
    prop_expected="$(remote_expected_hash "$manifest" "module.prop")"
    so_expected="$(remote_expected_hash "$manifest" "zygisk/arm64-v8a.so")"
    [ -n "$prop_expected" ] || return 1
    [ -n "$so_expected" ] || return 1

    prop_hash="$(sha256_file "$PROP_FILE")" || return 1
    so_hash="$(sha256_file "$ZYGISK_SO")" || return 1
    [ "$prop_hash" = "$prop_expected" ] || return 1
    [ "$so_hash" = "$so_expected" ] || return 1
    return 0
}

apply_props() {
    for key in \
        ro.product.marketname \
        ro.config.marketing_name \
        ro.product.display \
        ro.product.hn_model \
        ro.vendor.product.ztename \
        ro.vendor.vivo.market.name \
        ro.vivo.internet.name \
        ro.vendor.oplus.market.name \
        ro.oppo.market.name \
        ro.product.vendor.marketname \
        ro.product.system.marketname \
        ro.product.product.marketname \
        ro.product.odm.marketname \
        ro.vendor.asus.product.mkt_name \
        ro.lge.petname \
        ro.boot.vendor.lge.petname
    do
        set_prop "$key" "$TARGET_NAME"
    done
}

print_line "Pura80Ultra Semantics"
print_line "Checking GitHub official hashes..."
check_remote_hashes
rc="$?"
case "$rc" in
    0)
        touch "$ENABLE_FILE"
        echo "ok" > "$STATE_FILE"
        set_prop "persist.ak.ultra.v" "1"
        set_prop "persist.ak.ultra.s" "official_enabled"
        apply_props
        print_line "Official verification passed"
        print_line "Module enabled; reopen target apps or reboot"
        exit 0
        ;;
    1)
        rm -f "$ENABLE_FILE"
        echo "fail" > "$STATE_FILE"
        set_description "$FAIL_DESC"
        set_prop "persist.ak.ultra.v" "0"
        set_prop "persist.ak.ultra.s" "remote_mismatch"
        print_line "GitHub hash mismatch, module disabled"
        exit 1
        ;;
    *)
        rm -f "$ENABLE_FILE"
        echo "wait_action" > "$STATE_FILE"
        set_prop "persist.ak.ultra.v" "0"
        set_prop "persist.ak.ultra.s" "remote_unavailable"
        print_line "GitHub unavailable, module not enabled"
        exit 1
        ;;
esac
