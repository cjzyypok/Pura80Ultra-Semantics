#!/system/bin/sh

MODULE_ID="pura80ultra_semantics"
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/$MODULE_ID"

TARGET_NAME="HUAWEI Pura 80 Ultra"
FAIL_DESC="Unofficial version, disabled"
STATE_FILE="$MODDIR/.integrity_state"
ENABLE_FILE="$MODDIR/.enabled"
PROP_FILE="$MODDIR/module.prop"
ZYGISK_SO="$MODDIR/zygisk/arm64-v8a.so"

EXPECTED_MODULE_PROP_SHA256="6f7e3423f627291654ac4bd75d9b39e038f90fe9c2dfce68f69451c64e8ec95c"
EXPECTED_ZYGISK_SO_SHA256="b7a813736386cb300419100f963fdb18baf764a25037ab41b8f401dcae951d90"

sha256_file() {
    local file="$1"
    [ -f "$file" ] || return 1
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    if command -v toybox >/dev/null 2>&1; then
        toybox sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    return 1
}

set_prop() {
    local key="$1"
    local val="$2"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop "$key" "$val" >/dev/null 2>&1
    else
        setprop "$key" "$val" >/dev/null 2>&1
    fi
}

set_description() {
    local desc="$1"
    local tmp="$PROP_FILE.tmp.$$"
    local seen=0
    [ -f "$PROP_FILE" ] || return 0

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            description=*)
                echo "description=$desc"
                seen=1
                ;;
            *)
                echo "$line"
                ;;
        esac
    done < "$PROP_FILE" > "$tmp"

    [ "$seen" = "1" ] || echo "description=$desc" >> "$tmp"
    mv "$tmp" "$PROP_FILE"
}

check_local_hashes() {
    local prop_hash
    local so_hash

    prop_hash="$(sha256_file "$PROP_FILE")" || return 1
    so_hash="$(sha256_file "$ZYGISK_SO")" || return 1

    [ "$prop_hash" = "$EXPECTED_MODULE_PROP_SHA256" ] || return 1
    [ "$so_hash" = "$EXPECTED_ZYGISK_SO_SHA256" ] || return 1
    return 0
}

apply_props() {
    for key in \
        ro.product.marketname \
        ro.config.marketing_name \
        ro.product.display \
        ro.product.hn_model \
        ro.vendor.product.ztename \
        ro.vendor.vivo.market.name \
        ro.vivo.internet.name \
        ro.vendor.oplus.market.name \
        ro.oppo.market.name \
        ro.product.vendor.marketname \
        ro.product.system.marketname \
        ro.product.product.marketname \
        ro.product.odm.marketname \
        ro.vendor.asus.product.mkt_name \
        ro.lge.petname \
        ro.boot.vendor.lge.petname
    do
        set_prop "$key" "$TARGET_NAME"
    done
}

if [ ! -f "$ENABLE_FILE" ]; then
    echo "wait_action" > "$STATE_FILE"
    set_prop "persist.apankernel.pura80ultra.verified" "0"
    set_prop "persist.apankernel.pura80ultra.status" "waiting_action"
    exit 0
fi

if ! check_local_hashes; then
    rm -f "$ENABLE_FILE"
    echo "fail" > "$STATE_FILE"
    set_description "$FAIL_DESC"
    set_prop "persist.apankernel.pura80ultra.verified" "0"
    set_prop "persist.apankernel.pura80ultra.status" "local_mismatch"
    exit 0
fi

echo "ok" > "$STATE_FILE"
set_prop "persist.apankernel.pura80ultra.verified" "1"
set_prop "persist.apankernel.pura80ultra.status" "enabled"
apply_props
exit 0
