#!/system/bin/sh

MODULE_ID="pura80ultra_semantics"
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/$MODULE_ID"

TARGET_NAME="HUAWEI Pura 80 Ultra"
FAIL_DESC="Unofficial version, disabled"
STATE_FILE="$MODDIR/.integrity_state"
ENABLE_FILE="$MODDIR/.enabled"
PROP_FILE="$MODDIR/module.prop"
ZYGISK_SO="$MODDIR/zygisk/arm64-v8a.so"

set_prop() {
    local key="$1"
    local val="$2"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop "$key" "$val" >/dev/null 2>&1
    else
        setprop "$key" "$val" >/dev/null 2>&1
    fi
}

set_description() {
    local desc="$1"
    local tmp="$PROP_FILE.tmp.$$"
    local seen=0
    [ -f "$PROP_FILE" ] || return 0

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            description=*)
                echo "description=$desc"
                seen=1
                ;;
            *)
                echo "$line"
                ;;
        esac
    done < "$PROP_FILE" > "$tmp"

    [ "$seen" = "1" ] || echo "description=$desc" >> "$tmp"
    mv "$tmp" "$PROP_FILE"
}

apply_props() {
    for key in \
        ro.product.marketname \
        ro.config.marketing_name \
        ro.product.display \
        ro.product.hn_model \
        ro.vendor.product.ztename \
        ro.vendor.vivo.market.name \
        ro.vivo.internet.name \
        ro.vendor.oplus.market.name \
        ro.oppo.market.name \
        ro.product.vendor.marketname \
        ro.product.system.marketname \
        ro.product.product.marketname \
        ro.product.odm.marketname \
        ro.vendor.asus.product.mkt_name \
        ro.lge.petname \
        ro.boot.vendor.lge.petname
    do
        set_prop "$key" "$TARGET_NAME"
    done
}

if [ ! -f "$ENABLE_FILE" ]; then
    echo "wait_action" > "$STATE_FILE"
    set_prop "persist.ak.ultra.v" "0"
    set_prop "persist.ak.ultra.s" "waiting_action"
    exit 0
fi

echo "ok" > "$STATE_FILE"
set_prop "persist.ak.ultra.v" "1"
set_prop "persist.ak.ultra.s" "enabled"
apply_props
exit 0
