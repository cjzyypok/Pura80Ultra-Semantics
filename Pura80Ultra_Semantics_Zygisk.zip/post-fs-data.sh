#!/system/bin/sh

MODULE_ID="pura80ultra_semantics"
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/$MODULE_ID"

TARGET_NAME="HUAWEI Pura 80 Ultra"
ORIGINAL_DESC="Spoof Android Build/SystemProperties as HUAWEI Pura 80 Ultra"
FAIL_DESC="非官方版本，不会生效"
STATE_FILE="$MODDIR/.integrity_state"
PROP_FILE="$MODDIR/module.prop"
ZYGISK_SO="$MODDIR/zygisk/arm64-v8a.so"

# Optional: put a GitHub raw URL here after publishing official hashes.
# Format:
# module.prop <sha256>
# zygisk/arm64-v8a.so <sha256>
OFFICIAL_SHA256_URL=""

EXPECTED_MODULE_PROP_SHA256="6f7e3423f627291654ac4bd75d9b39e038f90fe9c2dfce68f69451c64e8ec95c"
EXPECTED_ZYGISK_SO_SHA256="a2c347f6babe59bfc7afbd764fc4941674024fe15baa1d2aada2ca5bd838ee8b"

sha256_file() {
    local file="$1"
    [ -f "$file" ] || return 1
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    if command -v toybox >/dev/null 2>&1; then
        toybox sha256sum "$file" | awk '{print $1}'
        return 0
    fi
    return 1
}

set_prop() {
    local key="$1"
    local val="$2"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop "$key" "$val" >/dev/null 2>&1
    else
        setprop "$key" "$val" >/dev/null 2>&1
    fi
}

set_description() {
    local desc="$1"
    local tmp="$PROP_FILE.tmp.$$"
    local seen=0
    [ -f "$PROP_FILE" ] || return 0

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            description=*)
                echo "description=$desc"
                seen=1
                ;;
            *)
                echo "$line"
                ;;
        esac
    done < "$PROP_FILE" > "$tmp"

    [ "$seen" = "1" ] || echo "description=$desc" >> "$tmp"
    mv "$tmp" "$PROP_FILE"
}

mark_failed() {
    mkdir -p "$MODDIR" >/dev/null 2>&1
    echo "fail" > "$STATE_FILE"
    set_description "$FAIL_DESC"
    set_prop "persist.apankernel.pura80ultra.verified" "0"
    set_prop "persist.apankernel.pura80ultra.status" "unofficial"
}

mark_ok() {
    mkdir -p "$MODDIR" >/dev/null 2>&1
    echo "ok" > "$STATE_FILE"
    set_description "$ORIGINAL_DESC"
    set_prop "persist.apankernel.pura80ultra.verified" "1"
    set_prop "persist.apankernel.pura80ultra.status" "official"
}

check_local_hashes() {
    local prop_hash
    local so_hash

    prop_hash="$(sha256_file "$PROP_FILE")" || return 1
    so_hash="$(sha256_file "$ZYGISK_SO")" || return 1

    [ "$prop_hash" = "$EXPECTED_MODULE_PROP_SHA256" ] || return 1
    [ "$so_hash" = "$EXPECTED_ZYGISK_SO_SHA256" ] || return 1
    return 0
}

download_remote_hashes() {
    local out="$1"
    rm -f "$out"

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL "$OFFICIAL_SHA256_URL" -o "$out" >/dev/null 2>&1 && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$out" "$OFFICIAL_SHA256_URL" >/dev/null 2>&1 && return 0
    fi
    if command -v toybox >/dev/null 2>&1; then
        toybox wget -q -O "$out" "$OFFICIAL_SHA256_URL" >/dev/null 2>&1 && return 0
    fi
    return 1
}

remote_expected_hash() {
    local manifest="$1"
    local name="$2"
    grep "^$name " "$manifest" 2>/dev/null | head -n 1 | awk '{print $2}'
}

check_remote_hashes() {
    [ -n "$OFFICIAL_SHA256_URL" ] || return 0

    local manifest="$MODDIR/.official_sha256"
    local prop_expected
    local so_expected
    local prop_hash
    local so_hash

    download_remote_hashes "$manifest" || return 1
    prop_expected="$(remote_expected_hash "$manifest" "module.prop")"
    so_expected="$(remote_expected_hash "$manifest" "zygisk/arm64-v8a.so")"
    [ -n "$prop_expected" ] || return 1
    [ -n "$so_expected" ] || return 1

    prop_hash="$(sha256_file "$PROP_FILE")" || return 1
    so_hash="$(sha256_file "$ZYGISK_SO")" || return 1
    [ "$prop_hash" = "$prop_expected" ] || return 1
    [ "$so_hash" = "$so_expected" ] || return 1
    return 0
}

if ! check_local_hashes || ! check_remote_hashes; then
    mark_failed
    exit 0
fi

mark_ok

for key in \
    ro.product.marketname \
    ro.config.marketing_name \
    ro.product.display \
    ro.product.hn_model \
    ro.vendor.product.ztename \
    ro.vendor.vivo.market.name \
    ro.vivo.internet.name \
    ro.vendor.oplus.market.name \
    ro.oppo.market.name \
    ro.product.vendor.marketname \
    ro.product.system.marketname \
    ro.product.product.marketname \
    ro.product.odm.marketname \
    ro.vendor.asus.product.mkt_name \
    ro.lge.petname \
    ro.boot.vendor.lge.petname
do
    set_prop "$key" "$TARGET_NAME"
done
