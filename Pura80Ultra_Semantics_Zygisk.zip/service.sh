#!/system/bin/sh

MODULE_ID="pura80ultra_semantics"
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/$MODULE_ID"

STATE_FILE="$MODDIR/.integrity_state"
ENABLE_FILE="$MODDIR/.enabled"

if [ -f "$ENABLE_FILE" ]; then
    [ -f "$STATE_FILE" ] || echo "wait_action" > "$STATE_FILE"
    setprop persist.apankernel.pura80ultra.status "enabled_waiting_action" >/dev/null 2>&1
else
    echo "wait_action" > "$STATE_FILE"
    setprop persist.apankernel.pura80ultra.status "waiting_action" >/dev/null 2>&1
fi

exit 0
