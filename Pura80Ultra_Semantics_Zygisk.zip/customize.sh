#!/system/bin/sh

MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/pura80ultra_semantics"

ui_print() {
    echo "$1"
}

ui_print "- Pura80Ultra Semantics"
ui_print "- Installation integrity checks will run after reboot"
ui_print "- If hashes mismatch, module will stay inactive"

exit 0
